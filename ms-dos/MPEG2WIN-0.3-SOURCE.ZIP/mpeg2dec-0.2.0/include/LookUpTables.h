// include file with look-up tables for YUV modifications
// by O.J. Maurice 2001

char LUT_U[256];
char LUT_V[256];
