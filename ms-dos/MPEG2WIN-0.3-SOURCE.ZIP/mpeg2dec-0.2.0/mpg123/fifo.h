#include <windows.h>

int audiohead,audiotail;
int videohead,videotail;
int GlobalAudioStarted;

void AudioFifoIn (char *buf,int bufsize);

int AudioFifoOut (char *buf,int wanted);

void AudioFifoInit ();

int AudioFifoEmpty ();

void VideoFifoIn (char *buf,int bufsize);

int VideoFifoOut (char *buf,int wanted);

void VideoFifoInit ();

int VideoFifoEmpty ();

int SyncFrames;

int FrameCounter;

RECT VideoRect;

int SurWidth;
int SurHeight;

int FrameWidth;
int FrameHeight;