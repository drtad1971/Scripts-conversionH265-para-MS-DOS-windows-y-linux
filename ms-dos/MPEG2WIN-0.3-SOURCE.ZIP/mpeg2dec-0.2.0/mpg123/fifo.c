#include <memory.h>
#include <stdlib.h>
#include "FIFO.h"

#define VIDEOBUFSIZE (256000*8)
#define AUDIOBUFSIZE (256000)

/* Audio Fifo */

char audiocircbuf[AUDIOBUFSIZE];
//int audiohead,audiotail;

void AudioFifoIn (char *buf,int bufsize)
{
	int DoWait;

	DoWait=1;

	do
	{
	 	if (audiohead<audiotail)
		{
			if (AUDIOBUFSIZE-(audiohead-audiotail+AUDIOBUFSIZE)<bufsize+1) 
			{
				Sleep (100);
			} else DoWait=0;
		} else {
			if (AUDIOBUFSIZE-(audiohead-audiotail)<bufsize+1)
			{
				Sleep (100);
			} else DoWait=0;
		}
	} while (DoWait);

	if (audiohead+bufsize<AUDIOBUFSIZE) {
		memcpy (&audiocircbuf[audiohead],buf,bufsize);
		audiohead+=bufsize;
	} else {
		memcpy (&audiocircbuf[audiohead],buf,AUDIOBUFSIZE-audiohead);
		memcpy (&audiocircbuf[0],(char *)(buf+AUDIOBUFSIZE-audiohead),bufsize-(AUDIOBUFSIZE-audiohead));
		audiohead+=bufsize-AUDIOBUFSIZE;
	}
}

int AudioFifoOut (char *buf,int wanted)
{
	int available;

	available=audiohead-audiotail;
	if (available<0) available+=AUDIOBUFSIZE;

	if (available>wanted) available=wanted;

	if (available+audiotail>AUDIOBUFSIZE) {
		memcpy ((char*)(buf),&audiocircbuf[audiotail],AUDIOBUFSIZE-audiotail);
		memcpy ((char*)(buf+(AUDIOBUFSIZE-audiotail)),&audiocircbuf[0],available-(AUDIOBUFSIZE-audiotail));
		audiotail+=available-AUDIOBUFSIZE;
	} else {
		memcpy ((char*)(buf),&audiocircbuf[audiotail],available);
		audiotail+=available;
	}

	return (available);
}

int AudioFifoEmpty ()
{
	if (audiohead!=audiotail)
	{
		return (0);
	} else {
		return (1);
	}
}

void AudioFifoInit ()
{
	audiohead=0;
	audiotail=0;
        GlobalAudioStarted=0;
}

/* Video Fifo */

char videocircbuf[VIDEOBUFSIZE];
//int videohead,videotail;

void VideoFifoIn (char *buf,int bufsize)
{
	int DoWait;

	DoWait=1;

	do 
	{
	 	if (videohead<videotail)
		{
			if (VIDEOBUFSIZE-(videohead-videotail+VIDEOBUFSIZE)<bufsize+1) 
			{
				Sleep (100);
			} else DoWait=0;
		} else {
			if (VIDEOBUFSIZE-(videohead-videotail)<bufsize+1)
			{
				Sleep (100);
			} else DoWait=0;
		}
	} while (DoWait);

	if (videohead+bufsize<VIDEOBUFSIZE) {
		memcpy (&videocircbuf[videohead],buf,bufsize);
		videohead+=bufsize;
	} else {
		memcpy (&videocircbuf[videohead],buf,VIDEOBUFSIZE-videohead);
		memcpy (&videocircbuf[0],(char *)(buf+VIDEOBUFSIZE-videohead),bufsize-(VIDEOBUFSIZE-videohead));
		videohead+=bufsize-VIDEOBUFSIZE;
	}
}

int VideoFifoOut (char *buf,int wanted)
{
	int available;

	available=videohead-videotail;
	if (available<0) available+=VIDEOBUFSIZE;

	if (available>wanted) available=wanted;

	if (available+videotail>VIDEOBUFSIZE) {
		memcpy ((char*)(buf),&videocircbuf[videotail],VIDEOBUFSIZE-videotail);
		memcpy ((char*)(buf+(VIDEOBUFSIZE-videotail)),&videocircbuf[0],available-(VIDEOBUFSIZE-videotail));
		videotail+=available-VIDEOBUFSIZE;
	} else {
		memcpy ((char*)(buf),&videocircbuf[videotail],available);
		videotail+=available;
	}

	return (available);
}

int VideoFifoEmpty ()
{
	if (videohead!=videotail)
	{
		return (0);
	} else {
		return (1);
	}
}

void VideoFifoInit ()
{
	videohead=0;
	videotail=0;
}
