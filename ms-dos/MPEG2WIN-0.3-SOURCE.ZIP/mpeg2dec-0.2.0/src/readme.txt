A very preliminary release, just for testing.
barely any error checking, and not even the ID strings are changed, includes MUCH leftover code.
Usage :
MPEG2dec -x [left] -y [top] -w [width] -h [height] file.mpg

this plays file.mpg in the defined window-size.

Uses the file LUT.DAT to set the lookup tables for the U and V parts of the YUV images to be displayed. Crashes if its missing out :)
